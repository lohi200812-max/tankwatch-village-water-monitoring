# TankWatch – Pipri Gram Panchayat (v2)

Village water-tank monitoring with depletion forecasting, pump scheduling, hamlet-wise distribution,
leak detection and a rainfall-recharge simulator. English / हिन्दी / मराठी / ಕನ್ನಡ.

## Architecture (3-tier)

```
Browser SPA (public/)  ──HTTP/JSON──▶  Express API (server/routes, middleware)  ──▶  Services / data layer (server/services)
  ES modules: api, render, chart,        auth, validation, security headers,          simulation, forecast (pure), validation,
  i18n, util                             error handling, rate-limited login           auth, logger (audit), store (JSON file)
```

| Layer | Folder | Responsibility |
|---|---|---|
| Presentation | `public/js/` | Rendering only. Forecasts (hours left, time to full, tier) come from the server. Last snapshot cached in `localStorage` for offline viewing. |
| API | `server/routes`, `server/middleware`, `server/app.js` | REST endpoints, JWT-style auth, input validation, security headers, JSON errors. |
| Domain / data | `server/services` | `forecast.js` (pure functions), `simulation.js` (engine, seedable RNG), `validation.js`, `auth.js`, `logger.js`, `store.js`. |

## Run

```bash
npm install
cp .env.example .env      # optional; without it a demo login is used: operator / tankwatch-demo
npm start                 # http://localhost:3000
npm test                  # Jest + coverage
```

In `NODE_ENV=production` the server refuses to start unless `ADMIN_PASSWORD` and `TOKEN_SECRET` are set.

## API

Public (read-only): `GET /api/health`, `GET /api/state`, `POST /api/auth/login`.
Operator (Bearer token): `GET /api/events`, `POST /api/tanks/:id/mode|trip|burst`, `PUT /api/tanks/:id/schedule`,
`POST /api/slots`, `DELETE /api/slots/:i`, `POST /api/recharge`, `POST /api/sim/skip|speed|reset`.

## Security notes
- Anyone can view the dashboard; every command requires login. Passwords hashed with scrypt; tokens are HMAC-signed with an 8 h expiry; login limited to 5 attempts / 15 min / IP.
- All input validated server-side (time format, window order/overlap, duration 10–180 min, slot must end before midnight, rainfall 0–300 mm, catchment 1–50 ha, whitelisted modes/speeds).
- CSP + nosniff + frame-deny headers, 10 kB body limit, all server text HTML-escaped in the UI.

## Audit log
Pump trips, mode changes, schedule edits, logins, leak flags and tier changes are recorded with the acting user
(`data/events.log`, JSON lines). `GET /api/events` returns recent events and trip counts per pump.

## Tests
`tests/` covers forecasting (`hoursLeft`, `fillHours`, tiers, leak rule), validation, auth/tokens/rate limiter,
the simulation engine (deterministic seed), logger, config and the HTTP API (supertest).

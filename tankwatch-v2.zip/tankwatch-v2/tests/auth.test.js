const A = require('../server/services/auth');
const SECRET = 'test-secret';

describe('password hashing', () => {
  it('verifies the right password and rejects the wrong one', () => {
    const h = A.hashPassword('s3cret');
    expect(A.verifyPassword('s3cret', h)).toBe(true);
    expect(A.verifyPassword('wrong', h)).toBe(false);
  });
  it('uses a random salt per hash and rejects malformed stored values', () => {
    expect(A.hashPassword('x')).not.toBe(A.hashPassword('x'));
    expect(A.verifyPassword('x', 'garbage')).toBe(false);
  });
});

describe('tokens', () => {
  const now = 1_700_000_000_000;
  it('round-trips a valid token', () => {
    const t = A.createToken('operator', SECRET, 60, now);
    expect(A.verifyToken(t, SECRET, now + 1000).sub).toBe('operator');
  });
  it('rejects expired, tampered, wrong-secret and malformed tokens', () => {
    const t = A.createToken('operator', SECRET, 60, now);
    expect(A.verifyToken(t, SECRET, now + 61_000)).toBeNull();
    expect(A.verifyToken(t, 'other', now)).toBeNull();
    const [body, sig] = t.split('.');
    const forged = Buffer.from(JSON.stringify({ sub: 'admin', exp: 9999999999 })).toString('base64url');
    expect(A.verifyToken(`${forged}.${sig}`, SECRET, now)).toBeNull();
    expect(A.verifyToken(body, SECRET, now)).toBeNull();
    expect(A.verifyToken(undefined, SECRET, now)).toBeNull();
    expect(A.verifyToken('a.b', SECRET, now)).toBeNull();
  });
});

describe('login limiter', () => {
  it('blocks after max attempts and resets after the window', () => {
    let now = 0; const allow = A.createLimiter(3, 1000, () => now);
    expect([allow('ip'), allow('ip'), allow('ip'), allow('ip')]).toEqual([true, true, true, false]);
    expect(allow('other')).toBe(true);
    now = 1500; expect(allow('ip')).toBe(true);
  });
});

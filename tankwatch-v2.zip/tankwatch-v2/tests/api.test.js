const request = require('supertest');
const { createApp } = require('../server/app');
const { Simulation } = require('../server/services/simulation');
const { createLogger } = require('../server/services/logger');

const config = { adminUser: 'operator', adminPassword: 'pw-test', tokenSecret: 'secret', tokenTtlSec: 60 };
function setup() {
  const logger = createLogger(), sim = new Simulation({ rng: () => 0.5, logger });
  return { app: createApp({ sim, logger, config }), sim };
}
const login = async app => (await request(app).post('/api/auth/login').send({ username: 'operator', password: 'pw-test' })).body.token;

describe('public endpoints', () => {
  it('serves health and read-only state without login', async () => {
    const { app } = setup();
    expect((await request(app).get('/api/health')).body).toEqual({ ok: true });
    const r = await request(app).get('/api/state'); expect(r.status).toBe(200); expect(r.body.tanks).toHaveLength(4);
  });
  it('sets security headers and hides X-Powered-By', async () => {
    const r = await request(setup().app).get('/api/health');
    expect(r.headers['x-content-type-options']).toBe('nosniff'); expect(r.headers['x-powered-by']).toBeUndefined();
  });
  it('returns JSON 404 for unknown API routes (401 first if not logged in, so routes are not probed)', async () => {
    const { app } = setup();
    expect((await request(app).get('/api/nope')).status).toBe(401);
    const t = await login(app);
    expect((await request(app).get('/api/nope').set('Authorization', `Bearer ${t}`)).status).toBe(404);
  });
});

describe('authentication', () => {
  it('rejects bad credentials and malformed bodies', async () => {
    const { app } = setup();
    expect((await request(app).post('/api/auth/login').send({ username: 'operator', password: 'bad' })).status).toBe(401);
    expect((await request(app).post('/api/auth/login').send({ username: 'operator' })).status).toBe(400);
    expect((await request(app).post('/api/auth/login').set('Content-Type', 'application/json').send('{bad')).status).toBe(400);
  });
  it('throttles repeated failed logins', async () => {
    const { app } = setup(); let last;
    for (let i = 0; i < 7; i++) last = await request(app).post('/api/auth/login').send({ username: 'operator', password: 'bad' });
    expect(last.status).toBe(429);
  });
  it('blocks every command without a valid token', async () => {
    const { app } = setup();
    expect((await request(app).post('/api/tanks/0/mode').send({ mode: 'on' })).status).toBe(401);
    expect((await request(app).post('/api/sim/reset')).status).toBe(401);
    expect((await request(app).get('/api/events').set('Authorization', 'Bearer nope')).status).toBe(401);
  });
});

describe('operator commands', () => {
  it('changes pump mode and records the operator in the audit log', async () => {
    const { app } = setup(); const t = await login(app);
    const r = await request(app).post('/api/tanks/1/mode').set('Authorization', `Bearer ${t}`).send({ mode: 'on' });
    expect(r.status).toBe(200); expect(r.body.tanks[1].mode).toBe('on');
    const ev = await request(app).get('/api/events').set('Authorization', `Bearer ${t}`);
    expect(ev.body.events[0]).toMatchObject({ type: 'pump_mode', by: 'operator' });
  });
  it('rejects invalid tank ids, modes, schedules, slots and recharge values with 400', async () => {
    const { app } = setup(); const t = await login(app), a = r => r.set('Authorization', `Bearer ${t}`);
    expect((await a(request(app).post('/api/tanks/9/mode')).send({ mode: 'on' })).status).toBe(400);
    expect((await a(request(app).post('/api/tanks/0/mode')).send({ mode: 'explode' })).status).toBe(400);
    expect((await a(request(app).put('/api/tanks/0/schedule')).send({ am: ['09:00', '08:00'], pm: ['20:00', '21:00'] })).status).toBe(400);
    expect((await a(request(app).post('/api/slots')).send({ w: 0, s: '23:50', d: 60 })).status).toBe(400);
    expect((await a(request(app).post('/api/recharge')).send({ mm: 9999, ha: 5 })).status).toBe(400);
    expect((await a(request(app).post('/api/sim/speed')).send({ speed: 1000 })).status).toBe(400);
  });
  it('adds and removes slots, and 404s on unknown slot', async () => {
    const { app, sim } = setup(); const t = await login(app), a = r => r.set('Authorization', `Bearer ${t}`);
    const n = sim.S.slots.length;
    expect((await a(request(app).post('/api/slots')).send({ w: 2, s: '10:00', d: 30 })).body.slots).toHaveLength(n + 1);
    expect((await a(request(app).delete(`/api/slots/${n}`))).body.slots).toHaveLength(n);
    expect((await a(request(app).delete('/api/slots/99'))).status).toBe(404);
  });
  it('updates the schedule, skips time and resets', async () => {
    const { app, sim } = setup(); const t = await login(app), a = r => r.set('Authorization', `Bearer ${t}`);
    const s = await a(request(app).put('/api/tanks/0/schedule')).send({ am: ['04:00', '05:00'], pm: ['19:00', '20:00'] });
    expect(s.body.tanks[0].sched.am).toEqual(['04:00', '05:00']);
    const m0 = sim.S.m; await a(request(app).post('/api/sim/skip')); expect(sim.S.m).toBe(m0 + 180);
    await a(request(app).post('/api/sim/reset')); expect(sim.S.m).toBe(17.5 * 60);
  });
});

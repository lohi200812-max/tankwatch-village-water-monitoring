const V = require('../server/services/validation');

describe('time / mode / speed / tankId', () => {
  it('accepts valid HH:MM and rejects bad formats', () => {
    expect(V.time('06:30').ok).toBe(true);
    ['6:30', '24:00', '12:60', '', null, 630, '12:5'].forEach(v => expect(V.time(v).ok).toBe(false));
  });
  it('validates modes and speeds', () => {
    expect(V.mode('auto').ok).toBe(true); expect(V.mode('boom').ok).toBe(false);
    expect(V.speed(12).ok).toBe(true); expect(V.speed(5).ok).toBe(false); expect(V.speed('4').ok).toBe(false);
  });
  it('parses tank ids from route params within range', () => {
    expect(V.tankId('2', 4)).toEqual({ ok: true, value: 2 });
    ['4', '-1', 'abc', '1.5', null].forEach(v => expect(V.tankId(v, 4).ok).toBe(false));
  });
});

describe('schedule', () => {
  const good = { am: ['05:00', '07:00'], pm: ['20:30', '23:00'] };
  it('accepts a valid pair of windows', () => expect(V.schedule(good)).toEqual({ ok: true, value: good }));
  it('rejects end <= start, missing windows, windows over 12h, and overlaps', () => {
    expect(V.schedule({ ...good, am: ['07:00', '07:00'] }).ok).toBe(false);
    expect(V.schedule({ ...good, am: ['08:00', '07:00'] }).ok).toBe(false);
    expect(V.schedule({ am: good.am }).ok).toBe(false);
    expect(V.schedule({ ...good, pm: ['08:00', '21:00'] }).ok).toBe(false);
    expect(V.schedule({ am: ['05:00', '09:00'], pm: ['08:00', '10:00'] }).ok).toBe(false);
    expect(V.schedule(null).ok).toBe(false);
  });
});

describe('slot', () => {
  it('accepts a valid slot', () => expect(V.slot({ w: 1, s: '18:00', d: 45 }, 4).ok).toBe(true));
  it('rejects unknown hamlet, bad time, bad/non-integer duration', () => {
    expect(V.slot({ w: 4, s: '18:00', d: 45 }, 4).ok).toBe(false);
    expect(V.slot({ w: 0, s: '25:00', d: 45 }, 4).ok).toBe(false);
    expect(V.slot({ w: 0, s: '18:00', d: 9 }, 4).ok).toBe(false);
    expect(V.slot({ w: 0, s: '18:00', d: 181 }, 4).ok).toBe(false);
    expect(V.slot({ w: 0, s: '18:00', d: 45.5 }, 4).ok).toBe(false);
    expect(V.slot({ w: 0, s: '18:00', d: '45' }, 4).ok).toBe(false);
  });
  it('rejects slots running past midnight and exceeding the slot limit', () => {
    expect(V.slot({ w: 0, s: '23:30', d: 45 }, 4).ok).toBe(false);
    expect(V.slot({ w: 0, s: '23:00', d: 60 }, 4).ok).toBe(true);
    expect(V.slot({ w: 0, s: '10:00', d: 30 }, 4, V.MAX_SLOTS).ok).toBe(false);
  });
});

describe('recharge & credentials', () => {
  it('bounds rainfall and catchment', () => {
    expect(V.recharge({ mm: 60, ha: 5 }).ok).toBe(true);
    [{ mm: -1, ha: 5 }, { mm: 301, ha: 5 }, { mm: 60, ha: 0 }, { mm: 60, ha: 51 }, { mm: NaN, ha: 5 }, { mm: '60', ha: 5 }, null]
      .forEach(b => expect(V.recharge(b).ok).toBe(false));
  });
  it('requires string credentials of sane length', () => {
    expect(V.credentials({ username: 'a', password: 'b' }).ok).toBe(true);
    expect(V.credentials({ username: 'a' }).ok).toBe(false);
    expect(V.credentials({ username: 'a'.repeat(65), password: 'b' }).ok).toBe(false);
    expect(V.credentials({ username: { $ne: 1 }, password: 'b' }).ok).toBe(false);
  });
});

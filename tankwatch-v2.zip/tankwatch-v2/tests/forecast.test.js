const { hoursLeft, fillHours, tier, isLeaking, rechargeM3, avg, clamp } = require('../server/services/forecast');

const tank = (vol, net, cap = 50000) => ({ vol, cap, net });

describe('hoursLeft', () => {
  it('divides volume by average net outflow, in hours', () => {
    expect(hoursLeft(tank(6000, Array(12).fill(-100)))).toBeCloseTo(1, 5);   // 6000 L at 100 L/min = 60 min
  });
  it('uses the average of the window, not the latest value', () => {
    expect(hoursLeft(tank(3000, [-50, -150]))).toBeCloseTo(0.5, 5);
  });
  it('returns null when the tank is not draining', () => {
    expect(hoursLeft(tank(1000, Array(12).fill(0)))).toBeNull();
    expect(hoursLeft(tank(1000, Array(12).fill(40)))).toBeNull();
  });
  it('ignores tiny drains below the 0.5 L/min threshold', () => {
    expect(hoursLeft(tank(1000, Array(12).fill(-0.4)))).toBeNull();
  });
  it('is 0 for an empty draining tank', () => {
    expect(hoursLeft(tank(0, Array(12).fill(-10)))).toBe(0);
  });
});

describe('fillHours', () => {
  it('computes time to fill the remaining capacity', () => {
    expect(fillHours(tank(40000, Array(12).fill(100)))).toBeCloseTo(10000 / 100 / 60, 5);
  });
  it('returns null when full, draining or steady', () => {
    expect(fillHours(tank(50000, Array(12).fill(100)))).toBeNull();
    expect(fillHours(tank(100, Array(12).fill(-100)))).toBeNull();
    expect(fillHours(tank(100, Array(12).fill(0.3)))).toBeNull();
  });
});

describe('tier', () => {
  it.each([[19.9, 'crit'], [20, 'warn'], [39.9, 'warn'], [40, 'ok'], [94.9, 'ok'], [95, 'over'], [100, 'over']])(
    '%d%% -> %s', (pct, expected) => { expect(tier({ vol: pct, cap: 100 })).toBe(expected); });
});

describe('isLeaking', () => {
  it('flags only off-peak outflow above 2.2x benchmark + 10', () => {
    expect(isLeaking([100, 100], 8, true)).toBe(true);
    expect(isLeaking([27, 27], 8, true)).toBe(false);   // threshold is 2.2*8+10 = 27.6
    expect(isLeaking([28, 28], 8, true)).toBe(true);
  });
  it('does not flag during peak hours or normal outflow', () => {
    expect(isLeaking([100, 100], 8, false)).toBe(false);
    expect(isLeaking([8, 9, 8], 8, true)).toBe(false);
  });
});

describe('helpers', () => {
  it('rechargeM3 scales with rainfall and catchment', () => { expect(rechargeM3(60, 5)).toBeCloseTo(450, 5); expect(rechargeM3(0, 5)).toBe(0); });
  it('avg handles empty arrays', () => { expect(avg([])).toBe(0); expect(avg([2, 4])).toBe(3); });
  it('clamp bounds a value', () => { expect(clamp(5, 0, 3)).toBe(3); expect(clamp(-1, 0, 3)).toBe(0); expect(clamp(2, 0, 3)).toBe(2); });
});

const { Simulation, freshState, STATE_VERSION } = require('../server/services/simulation');
const { createLogger } = require('../server/services/logger');

// Deterministic PRNG (mulberry32) so simulation tests are repeatable.
const seeded = seed => () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const make = (seed = 1, extra = {}) => new Simulation({ rng: seeded(seed), clock: () => 1000, ...extra });

describe('simulation basics', () => {
  it('is deterministic for a given seed', () => {
    const a = make(7), b = make(7); a.tick(200); b.tick(200);
    expect(a.S.tanks.map(k => k.vol)).toEqual(b.S.tanks.map(k => k.vol));
  });
  it('keeps every tank volume within 0..capacity over several days', () => {
    const s = make(3); s.tick(288 * 5);
    s.S.tanks.forEach(k => { expect(k.vol).toBeGreaterThanOrEqual(0); expect(k.vol).toBeLessThanOrEqual(k.cap); });
  });
  it('advances 5 simulated minutes per tick and rolls the day over', () => {
    const s = make(); const m0 = s.S.m; s.step(); expect(s.S.m).toBe(m0 + 5);
    s.tick(288); expect(s.S.day).toBeGreaterThanOrEqual(1);
    expect(s.S.hourly).toHaveLength(24); expect(s.S.week).toHaveLength(7);
  });
  it('discards state of an incompatible version', () => {
    const s = new Simulation({ state: { v: 1 }, rng: seeded(1) }); expect(s.S.v).toBe(STATE_VERSION);
  });
  it('freshState starts every tank in a sane range', () => {
    freshState(seeded(2)).tanks.forEach(k => { expect(k.vol / k.cap).toBeGreaterThan(0.3); expect(k.vol / k.cap).toBeLessThan(0.9); });
  });
});

describe('pump behaviour', () => {
  it('runs in auto mode inside the schedule window and fills the tank', () => {
    const s = make(5, { rng: () => 0.5 });        // rng 0.5 -> never trips (needs < .0015)
    s.S.m = 5 * 60 + 55; const v0 = s.S.tanks[1].vol; s.tick(6);
    expect(s.S.tanks[1].run).toBe(true); expect(s.S.tanks[1].inn).toBeGreaterThan(0); expect(s.S.tanks[1].vol).toBeGreaterThan(v0 - 1);
  });
  it('stays idle in auto mode outside the schedule window', () => {
    const s = make(5, { rng: () => 0.5 }); s.S.m = 12 * 60; s.tick(1);
    expect(s.S.tanks[1].run).toBe(false); expect(s.S.tanks[1].volt).toBeGreaterThan(400);
  });
  it('a tripped pump never runs and reads 0 V; mode change clears the trip unless "off"', () => {
    const s = make(5, { rng: () => 0.5 });
    s.setTrip(0, true); s.setMode(0, 'on'); expect(s.S.tanks[0].trip).toBe(false);
    s.setTrip(0, true); s.setMode(0, 'off'); expect(s.S.tanks[0].trip).toBe(true);
    s.tick(1); expect(s.S.tanks[0].run).toBe(false); expect(s.S.tanks[0].volt).toBe(0);
  });
  it('logs a pump_trip event with the pump number when a random trip occurs', () => {
    const logger = createLogger(); const s = make(1, { logger, rng: () => 0 });   // rng 0 -> always trips while running
    s.setMode(1, 'on'); s.tick(1);
    expect(logger.recent(10, 'pump_trip')[0]).toMatchObject({ pump: 1 });
    expect(logger.pumpFailures()[1]).toBeGreaterThanOrEqual(1);
  });
});

describe('leaks, slots, recharge', () => {
  it('flags a simulated burst in off-peak hours and clears after repair', () => {
    const s = make(4, { rng: () => 0.5 }); s.S.m = 1 * 60; s.toggleBurst(1); s.tick(8);
    expect(s.S.tanks[1].flag).toBe(true);
    s.toggleBurst(1); s.tick(10); expect(s.S.tanks[1].flag).toBe(false);
  });
  it('adds, removes and rejects removing unknown distribution slots', () => {
    const s = make(); const n = s.S.slots.length;
    s.addSlot({ w: 1, s: '10:00', d: 20 }); expect(s.S.slots).toHaveLength(n + 1);
    expect(s.removeSlot(n)).toBe(true); expect(s.removeSlot(99)).toBe(false); expect(s.removeSlot(-1)).toBe(false);
  });
  it('records slot minutes in the distribution log', () => {
    const s = make(2, { rng: () => 0.5 }); s.S.slots = [{ w: 0, s: '06:00', d: 30 }]; s.S.m = 6 * 60 - 5; s.tick(8);
    expect(s.S.log[0].min).toBe(30);
  });
  it('recharge adds groundwater and is capped at 3000 m³', () => {
    const s = make(); const g = s.S.gw; s.recharge(10, 2); expect(s.S.gw).toBe(g + 30);
    s.recharge(300, 50); expect(s.S.gw).toBe(3000);
  });
  it('writes an audit trail for operator commands', () => {
    const logger = createLogger(); const s = make(1, { logger });
    s.setSchedule(0, { am: ['05:00', '06:00'], pm: ['19:00', '20:00'] }, 'operator'); s.reset('operator');
    expect(logger.recent(5).map(e => e.type)).toEqual(expect.arrayContaining(['schedule_changed', 'reset']));
  });
});

describe('snapshot', () => {
  it('exposes server-computed forecasts and tier for each tank', () => {
    const snap = make().snapshot();
    expect(snap.tanks).toHaveLength(4);
    snap.tanks.forEach(t => { expect(['ok', 'warn', 'crit', 'over']).toContain(t.tier); expect(t).toHaveProperty('hoursLeft'); expect(t).toHaveProperty('fillHours'); });
    expect(snap.dailyUse).toBeGreaterThanOrEqual(60);
  });
});

const { loadConfig } = require('../server/config');
describe('config', () => {
  it('refuses to start in production without credentials and secret', () => {
    expect(() => loadConfig({ NODE_ENV: 'production' })).toThrow();
    expect(() => loadConfig({ NODE_ENV: 'production', ADMIN_PASSWORD: 'x', TOKEN_SECRET: 'y' })).not.toThrow();
  });
  it('generates a random secret per process in development', () => {
    expect(loadConfig({}).tokenSecret).not.toBe(loadConfig({}).tokenSecret);
  });
});

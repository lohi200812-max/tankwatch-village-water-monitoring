const fs = require('fs'); const os = require('os'); const path = require('path');
const { createLogger } = require('../server/services/logger');

describe('logger', () => {
  it('keeps a bounded ring buffer, newest first, with type filtering', () => {
    const l = createLogger({ max: 3 }); ['a', 'b', 'c', 'd'].forEach(t => l.log(t));
    expect(l.recent().map(e => e.type)).toEqual(['d', 'c', 'b']); expect(l.recent(10, 'c')).toHaveLength(1);
  });
  it('counts pump failures per pump', () => {
    const l = createLogger(); l.log('pump_trip', { pump: 2 }); l.log('pump_trip', { pump: 2 }); l.log('pump_trip', { pump: 1 });
    expect(l.pumpFailures()).toEqual({ 1: 1, 2: 2 });
  });
  it('mirrors events to a JSON-lines file and survives an unwritable path', () => {
    const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'tw-')), 'e.log');
    createLogger({ file: f }).log('x', { n: 1 }); expect(JSON.parse(fs.readFileSync(f, 'utf8').trim())).toMatchObject({ type: 'x', n: 1 });
    expect(() => createLogger({ file: '/nonexistent/dir/e.log' }).log('x')).not.toThrow();
  });
});

# What changed from v1 (mapped to the evaluation feedback)

| Feedback | Change |
|---|---|
| No real Node.js/Express backend | Simulation, forecasting, scheduling and persistence moved to `server/` behind a REST API. |
| No automated tests for `hoursLeft` / `fillHours` | `tests/forecast.test.js` + 5 more suites (Jest). |
| Minimal server-side validation of times/durations | `server/services/validation.js`, enforced on every write route. |
| Authentication not implemented | Operator login (scrypt + signed expiring tokens, rate-limited); dashboard stays public read-only. |
| Single `script.js` | Split into `public/js/{api,render,chart,i18n,util,main}.js` and `server/services/*`. |
| No pump-failure logging | `logger.js` audit trail, `/api/events`, per-pump failure counts shown in the UI. |

/** Thin client for the TankWatch REST API. Token lives in sessionStorage (cleared when the tab closes). */
const TOKEN_KEY = 'tw.token';
export const getToken = () => { try { return sessionStorage.getItem(TOKEN_KEY); } catch { return null; } };
const setToken = t => { try { t ? sessionStorage.setItem(TOKEN_KEY, t) : sessionStorage.removeItem(TOKEN_KEY); } catch { /* storage unavailable */ } };

export class ApiError extends Error { constructor(status, message) { super(message); this.status = status; } }

async function call(method, path, body) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken(); if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch('/api' + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && token) setToken(null);          // expired/invalid token -> back to view-only
  if (!res.ok) throw new ApiError(res.status, data.error || res.statusText);
  return data;
}
export const api = {
  state: () => call('GET', '/state'),
  login: async (username, password) => { const r = await call('POST', '/auth/login', { username, password }); setToken(r.token); return r; },
  logout: () => setToken(null),
  mode: (id, mode) => call('POST', `/tanks/${id}/mode`, { mode }),
  trip: (id, trip) => call('POST', `/tanks/${id}/trip`, { trip }),
  schedule: (id, am, pm) => call('PUT', `/tanks/${id}/schedule`, { am, pm }),
  burst: id => call('POST', `/tanks/${id}/burst`),
  addSlot: slot => call('POST', '/slots', slot),
  delSlot: i => call('DELETE', `/slots/${i}`),
  recharge: (mm, ha) => call('POST', '/recharge', { mm, ha }),
  skip: () => call('POST', '/sim/skip'),
  speed: speed => call('POST', '/sim/speed', { speed }),
  reset: () => call('POST', '/sim/reset'),
  events: () => call('GET', '/events')
};

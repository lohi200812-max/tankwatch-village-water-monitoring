/** Entry point: polls the API, renders snapshots, wires UI events to API calls. */
import { api, getToken, ApiError } from './api.js';
import { build, render, renderRain, renderEvents, setLang, getLang, t } from './render.js';
import { drawChart } from './chart.js';
import { $ } from './util.js';

const CACHE_KEY = 'tankwatch.cache.v2', POLL_MS = 1500;
let snap = null, view = 'day', simOff = false, sound = true, audio, tiers = {}, n = 0, cachedAt = 0, online = false;

const loadCache = () => { try { return JSON.parse(localStorage.getItem(CACHE_KEY)); } catch { return null; } };
const saveCache = s => { try { localStorage.setItem(CACHE_KEY, JSON.stringify(s)); } catch { /* quota / private mode */ } };
const flash = msg => { const e = $('#toast'); e.textContent = msg; e.hidden = false; clearTimeout(flash.id); flash.id = setTimeout(() => { e.hidden = true; }, 3500); };

function paint(rebuild = false) {
  if (!snap) return;
  if (rebuild) build(snap);
  const next = render(snap, { online: online && !simOff, cachedAt, canEdit: !!getToken() && online && !simOff });
  Object.keys(next).forEach(id => { if (tiers[id] !== undefined && tiers[id] !== next[id] && (next[id] === 'crit' || next[id] === 'over')) beep(next[id] === 'crit' ? 330 : 880); });
  tiers = next;
  if (rebuild || n++ % 4 === 0) paintChart();
}
function paintChart() {
  if (!snap) return;
  const c = drawChart(snap, view); $('#chart').innerHTML = c.svg; $('#legend').innerHTML = c.legend;
}
function beep(f) {
  if (!sound || !audio) return;
  try { [0, .35].forEach(d => { const o = audio.createOscillator(), g = audio.createGain(); o.frequency.value = f; o.connect(g); g.connect(audio.destination);
    g.gain.setValueAtTime(.2, audio.currentTime + d); g.gain.exponentialRampToValueAtTime(.001, audio.currentTime + d + .3); o.start(audio.currentTime + d); o.stop(audio.currentTime + d + .3); }); } catch { /* audio blocked */ }
}

/** Run a command; on success adopt the returned snapshot, on failure show the server's message. */
async function act(fn) {
  if (simOff) return;
  try { snap = await fn(); cachedAt = Date.now(); saveCache(snap); paint(); }
  catch (e) {
    if (e instanceof ApiError && e.status === 401) { flash('Please log in as operator'); openLogin(); }
    else flash(e instanceof ApiError ? e.message : 'Network error');
    paint();
  }
}

async function poll() {
  if (simOff) return;
  try { snap = await api.state(); online = true; cachedAt = Date.now(); saveCache(snap); }
  catch { online = false; }
  paint(!document.querySelector('#tanks .tank'));
}

/* ---------- login ---------- */
const dlg = () => $('#loginDlg');
function openLogin() { $('#loginErr').textContent = ''; if (!dlg().open) dlg().showModal(); }
$('#loginBtn').addEventListener('click', openLogin);
$('#logoutBtn').addEventListener('click', () => { api.logout(); paint(); });
$('#loginCancel').addEventListener('click', () => dlg().close());
$('#loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  try { await api.login($('#loginUser').value, $('#loginPass').value); $('#loginPass').value = ''; dlg().close(); paint(); }
  catch (err) { $('#loginErr').textContent = err instanceof ApiError ? err.message : 'Network error'; }
});

/* ---------- events ---------- */
document.addEventListener('click', () => { if (!audio) try { audio = new (window.AudioContext || window.webkitAudioContext)(); } catch { /* unsupported */ } }, { once: true });
$('#tanks').addEventListener('click', e => {
  const b = e.target.closest('[data-a]'); if (!b) return;
  const id = +b.closest('.tank').dataset.id, k = snap.tanks[id];
  act(() => b.dataset.a === 'trip' ? api.trip(id, !k.trip) : api.mode(id, b.dataset.a));
});
$('#pumps').addEventListener('change', e => {
  const row = e.target.closest('tr[data-k]'); if (!row) return;
  const v = w => row.querySelector(`[data-w="${w}"]`).value;
  act(() => api.schedule(+row.dataset.k, [v('am0'), v('am1')], [v('pm0'), v('pm1')]))
    .then(() => { if (snap) { const k = snap.tanks[+row.dataset.k]; row.querySelectorAll('[data-w]').forEach(i => { const w = i.dataset.w; i.value = k.sched[w.slice(0, 2)][+w[2]]; }); } });
});
$('#slotForm').addEventListener('submit', e => {
  e.preventDefault();
  act(() => api.addSlot({ w: +$('#slotWard').value, s: $('#slotTime').value, d: parseInt($('#slotDur').value, 10) }));
});
$('#dist').addEventListener('click', e => { const b = e.target.closest('[data-del]'); if (b) act(() => api.delSlot(+b.dataset.del)); });
$('#leaks').addEventListener('click', e => { const b = e.target.closest('[data-burst]'); if (b) act(() => api.burst(+b.dataset.burst)); });
document.querySelector('.tabs').addEventListener('click', e => {
  const b = e.target.closest('[data-v]'); if (!b) return; view = b.dataset.v;
  document.querySelectorAll('.tabs button').forEach(x => x.classList.toggle('on', x === b)); paintChart();
});
$('#chart').addEventListener('mouseover', e => { if (e.target.dataset.i) $('#chartInfo').textContent = e.target.dataset.i; });
$('#chart').addEventListener('click', e => { if (e.target.dataset.i) $('#chartInfo').textContent = e.target.dataset.i; });
$('#lang').addEventListener('change', e => { setLang(e.target.value); try { localStorage.setItem('tw.lang', getLang()); } catch { /* ignore */ } paint(true); });
$('#skip').addEventListener('click', () => act(api.skip));
$('#speed').addEventListener('change', e => act(() => api.speed(+e.target.value)));
$('#reset').addEventListener('click', () => { if (confirm('Reset all demo data?')) act(api.reset); });
$('#snd').addEventListener('click', e => { sound = !sound; e.currentTarget.textContent = sound ? '🔔' : '🔕'; e.currentTarget.setAttribute('aria-pressed', sound); });
$('#off').addEventListener('click', () => { simOff = !simOff; $('#off').classList.toggle('on', simOff); paint(); if (!simOff) poll(); });
$('#mm').addEventListener('input', () => snap && renderRain(snap)); $('#ha').addEventListener('input', () => snap && renderRain(snap));
$('#applyRain').addEventListener('click', () => act(() => api.recharge(+$('#mm').value, +$('#ha').value || 1)));
$('#eventsBtn').addEventListener('click', async () => { try { renderEvents(await api.events()); } catch (e) { flash(e instanceof ApiError && e.status === 401 ? 'Log in to view the pump failure log' : 'Could not load events'); } });
window.addEventListener('online', poll);
window.addEventListener('offline', () => { online = false; paint(); });

/* ---------- start ---------- */
try { setLang(localStorage.getItem('tw.lang') || 'en'); } catch { setLang('en'); }
snap = loadCache();               // show cached data instantly while the first request is in flight
if (snap) { cachedAt = snap.upd; paint(true); }
poll(); setInterval(poll, POLL_MS);

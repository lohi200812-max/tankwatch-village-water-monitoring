/** Escape text before inserting into innerHTML (names/log text come from the server). */
export const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const nf = x => Math.round(x).toLocaleString('en-IN');
export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const $ = s => document.querySelector(s);

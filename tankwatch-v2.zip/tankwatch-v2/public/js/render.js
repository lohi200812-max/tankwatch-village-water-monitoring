/** DOM rendering. Pure view layer: takes a server snapshot, never computes forecasts itself. */
import { esc, nf, $ } from './util.js';
import { TEXT } from './i18n.js';

let lang = 'en';
export const setLang = l => { lang = l; };
export const getLang = () => lang;
export const t = k => (TEXT[lang] && TEXT[lang][k]) || TEXT.en[k] || k;

export function applyI18n() {
  document.documentElement.lang = lang; $('#lang').value = lang; document.title = t('title');
  document.querySelectorAll('[data-i18n]').forEach(e => { e.textContent = t(e.dataset.i18n); });
}

/** Static parts (tank cards, pump table, hamlet select). Rebuilt only on first load / language change. */
export function build(snap) {
  $('#tanks').innerHTML = snap.tanks.map(k => `
  <article class="card tank" id="c${k.id}" data-id="${k.id}">
    <h3>${esc(k.name)}</h3>
    <div class="tk">
      <svg class="tsvg" viewBox="0 0 100 140" role="img" aria-label="${esc(k.name)}">
        <defs><clipPath id="cp${k.id}"><rect x="10" y="20" width="80" height="100" rx="8"/></clipPath></defs>
        <g clip-path="url(#cp${k.id})"><rect class="bg" x="10" y="20" width="80" height="100"/>
          <g class="water" id="w${k.id}" style="transform:translateY(120px)"><g class="wave"><path d="M-100 6 Q-87.5 0 -75 6 T-50 6 T-25 6 T0 6 T25 6 T50 6 T75 6 T100 6 T125 6 T150 6 V130 H-100Z"/></g></g></g>
        <line class="mark" x1="10" x2="90" y1="100" y2="100"/>
        <rect class="rim" x="10" y="20" width="80" height="100" rx="8"/>
        <text class="pt" id="p${k.id}" x="50" y="76">0%</text>
      </svg>
      <div class="info">
        <span class="chip" id="s${k.id}"></span>
        <p class="big"><b id="l${k.id}"></b> L <small id="m${k.id}"></small></p>
        <p><span data-i18n="buffer"></span>: <b id="b${k.id}"></b> L</p>
        <p class="hl" id="h${k.id}"></p>
        <p class="sub" id="ps${k.id}"></p>
      </div>
    </div>
    <div class="btns">
      <button data-a="on" data-i18n="start"></button><button data-a="off" data-i18n="stop"></button>
      <button data-a="auto" data-i18n="auto"></button><button data-a="trip" id="tr${k.id}"></button>
    </div>
  </article>`).join('');
  $('#pumps').innerHTML = '<table><thead><tr><th>Pump</th><th>Tank</th><th></th><th>V</th><th>Morning</th><th>Evening</th></tr></thead><tbody>' +
    snap.tanks.map(k => `<tr data-k="${k.id}"><td>#${k.pump}</td><td>${esc(k.name)}</td><td><span class="chip" id="pc${k.id}"></span></td><td id="pv${k.id}"></td>
      <td><input type="time" data-w="am0" value="${k.sched.am[0]}" aria-label="Morning start"> <input type="time" data-w="am1" value="${k.sched.am[1]}" aria-label="Morning end"></td>
      <td><input type="time" data-w="pm0" value="${k.sched.pm[0]}" aria-label="Evening start"> <input type="time" data-w="pm1" value="${k.sched.pm[1]}" aria-label="Evening end"></td></tr>`).join('') + '</tbody></table>';
  $('#slotWard').innerHTML = snap.wards.map((w, i) => `<option value="${i}">${esc(w)}</option>`).join('');
  applyI18n();
}

/** Returns alert tiers per tank so the caller can decide when to beep. */
export function render(snap, ctx) {
  const { online, cachedAt, canEdit } = ctx;
  $('#badge').className = 'badge ' + (online ? 'live' : 'cache');
  $('#badge').textContent = online ? '● ' + t('live') : '⚠ ' + t('cached') + ' · ' + new Date(cachedAt || snap.upd).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  $('#clock').textContent = `Day ${snap.day + 1} · ${snap.clock}`;
  document.body.classList.toggle('readonly', !canEdit);
  document.querySelectorAll('[data-needs-auth], #tanks [data-a], #pumps input').forEach(b => { b.disabled = !canEdit; });
  $('#roNote').hidden = canEdit;
  $('#loginBtn').hidden = canEdit; $('#logoutBtn').hidden = !canEdit;

  const alerts = [], tiers = {};
  snap.tanks.forEach(k => {
    const p = k.vol / k.cap * 100, tr = k.tier, hl = k.hoursLeft, fh = k.fillHours;
    tiers[k.id] = tr;
    $('#c' + k.id).className = 'card tank ' + tr;
    $('#w' + k.id).style.transform = `translateY(${20 + 100 * (1 - p / 100)}px)`;
    $('#p' + k.id).textContent = Math.round(p) + '%';
    $('#s' + k.id).textContent = t(tr);
    $('#l' + k.id).textContent = nf(k.vol);
    $('#m' + k.id).textContent = `(${(k.vol / 1000).toFixed(1)} m³ / ${(k.cap / 1000).toFixed(0)} m³)`;
    $('#b' + k.id).textContent = nf(Math.max(0, k.vol - .2 * k.cap));
    $('#h' + k.id).innerHTML = hl !== null ? `⏳ ${t('left')}: <b>${hl.toFixed(1)} ${t('hr')}</b>` : fh !== null ? `⬆ ${t('fullIn')} <b>${fh.toFixed(1)} ${t('hr')}</b>` : '✔ 100%';
    const st = k.trip ? 'tripped' : k.run ? 'running' : 'idle';
    $('#ps' + k.id).textContent = `Pump #${k.pump}: ${t(st)} · ${k.volt} V · Q ${nf(k.inn - k.out)} L/min`;
    $('#pc' + k.id).textContent = t(st); $('#pc' + k.id).className = 'chip ' + (k.trip ? 'crit' : k.run ? 'ok' : 'warn');
    $('#pv' + k.id).textContent = k.volt;
    $('#tr' + k.id).textContent = k.trip ? t('rst') : t('trip');
    document.querySelectorAll(`#c${k.id} [data-a]`).forEach(b => b.classList.toggle('on', b.dataset.a === k.mode));
    const eta = hl !== null ? `${t('empty')} ${hl.toFixed(1)} ${t('hr')}` : '';
    if (tr === 'crit') alerts.push(['crit', `${k.name}: ${t('crit')} (${p.toFixed(0)}%)`, eta]);
    else if (tr === 'warn') alerts.push(['warn', `${k.name}: ${t('warn')} (${p.toFixed(0)}%)`, eta]);
    else if (tr === 'over') alerts.push(['over', `${k.name}: ${t('over')} (${p.toFixed(0)}%)`, t('overMsg')]);
    if (k.trip) alerts.push(['crit', `Pump #${k.pump} ${t('tripped')}`, k.name]);
    if (k.flag) alerts.push(['warn', `${t('leak')}: ${k.name}`, 'Possible pipe burst – outflow far above off-peak benchmark']);
  });
  if (!alerts.length) alerts.push(['ok', t('allOk'), '']);
  $('#alerts').innerHTML = alerts.map(a => `<div class="al ${a[0]}">${esc(a[1])}${a[2] ? `<small>${esc(a[2])}</small>` : ''}</div>`).join('');
  renderDist(snap, canEdit); renderLeaks(snap, canEdit); renderRain(snap);
  return tiers;
}

function renderDist(snap, canEdit) {
  const dis = canEdit ? '' : ' disabled';
  $('#dist').innerHTML = snap.wards.map((w, i) => {
    const today = snap.log.filter(e => e.w === i && e.day === snap.day).reduce((a, e) => a + e.min, 0);
    const chips = snap.slots.map((s, j) => s.w === i ? `<span class="chip">${esc(s.s)} · ${s.d} min<button data-del="${j}" aria-label="Remove"${dis}>✕</button></span>` : '').join('');
    return `<div class="ward"><b>${esc(w)}</b><div class="bar"><i style="width:${Math.min(100, today / 90 * 100)}%"></i></div><span>${today} min</span><div class="chips">${chips}</div></div>`;
  }).join('') + '<p class="sub">' + snap.log.slice(-4).reverse().map(e => `Day ${e.day + 1} · ${esc(snap.wards[e.w])} ${esc(e.s)} → ${e.min} min`).join('<br>') + '</p>';
}
function renderLeaks(snap, canEdit) {
  $('#leaks').innerHTML = '<table><thead><tr><th>Tank</th><th>L/min</th><th>Benchmark</th><th></th><th></th></tr></thead><tbody>' +
    snap.tanks.map(k => `<tr><td>${esc(k.name)}</td><td>${nf(k.avgOut)}</td><td>${nf(k.benchmark)}</td>
    <td><span class="chip ${k.flag ? 'crit' : 'ok'}">${k.flag ? 'Possible burst' : 'Normal'}</span></td>
    <td><button data-burst="${k.id}"${canEdit ? '' : ' disabled'}>${k.leak ? 'Repair' : 'Simulate burst'}</button></td></tr>`).join('') + '</tbody></table>';
}
/** Preview only – the authoritative recharge calculation runs on the server when applied. */
export function renderRain(snap) {
  const mm = +$('#mm').value, ha = +$('#ha').value || 1, rech = mm * ha * 10 * .15, use = snap.dailyUse;
  $('#mmv').textContent = mm;
  $('#rainOut').textContent = `≈ ${rech.toFixed(0)} m³ recharge → +${(rech / use).toFixed(1)} days of village supply`;
  $('#gwBar').style.width = Math.min(100, Math.max(0, snap.gw / 3000 * 100)) + '%';
  $('#gwTxt').textContent = `Groundwater reserve: ${nf(snap.gw)} m³ ≈ ${(snap.gw / use).toFixed(1)} days at current use (${use.toFixed(0)} kL/day)`;
}

export function renderEvents(data) {
  const f = data.pumpFailures, el = $('#events');
  const summary = Object.keys(f).length ? Object.entries(f).map(([p, n]) => `Pump #${esc(p)}: ${n} trip${n > 1 ? 's' : ''}`).join(' · ') : 'No pump failures recorded';
  el.innerHTML = `<p class="hl">${summary}</p>` + '<table><tbody>' + data.events.slice(0, 12).map(e =>
    `<tr><td>${new Date(e.t).toLocaleTimeString()}</td><td>${esc(e.type)}</td><td>${esc(e.tank || e.pump || e.user || '')}</td></tr>`).join('') + '</tbody></table>';
}

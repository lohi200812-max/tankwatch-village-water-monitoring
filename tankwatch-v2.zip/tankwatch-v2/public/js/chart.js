/** Hand-built SVG bar chart (works offline, no dependencies). */
import { esc } from './util.js';
export const COL = ['#1d8fe1', '#14935f', '#d98e04', '#7a4fd6'];

export function drawChart(snap, view) {
  const W = 600, H = 230, p = { l: 34, r: 8, t: 12, b: 26 };
  let labels, series, names, cols, target = null;
  if (view === 'day') { labels = snap.hourly.map((_, i) => String(i)); series = [snap.hourly]; names = ['Village total (kL per hour)']; cols = [COL[0]]; }
  else {
    labels = snap.week.map((_, i) => new Date(Date.now() - (6 - i) * 864e5).toLocaleDateString([], { weekday: 'short' }));
    series = snap.wards.map((_, w) => snap.week.map(d => d[w])); names = snap.wards; cols = COL; target = 115;
  }
  const tot = labels.map((_, i) => series.reduce((a, s) => a + s[i], 0));
  const max = Math.max(...tot, target || 0, 1) * 1.15, ph = H - p.t - p.b, bw = (W - p.l - p.r) / labels.length;
  let g = '';
  for (let i = 0; i <= 4; i++) { const y = H - p.b - ph * i / 4; g += `<line x1="${p.l}" x2="${W - p.r}" y1="${y}" y2="${y}" stroke="#d9e5ea"/><text x="${p.l - 4}" y="${y + 3}" text-anchor="end">${Math.round(max * i / 4)}</text>`; }
  labels.forEach((l, i) => {
    let y = H - p.b; const x = p.l + i * bw + bw * .15;
    series.forEach((s, j) => { const bh = Math.max(0, s[i] / max * ph); y -= bh; g += `<rect x="${x}" y="${y}" width="${bw * .7}" height="${bh}" fill="${cols[j]}" data-i="${esc(l)} · ${esc(names[j])}: ${s[i].toFixed(1)} kL"/>`; });
    if (view === 'week' || i % 3 === 0) g += `<text x="${x + bw * .35}" y="${H - 8}" text-anchor="middle">${esc(l)}</text>`;
  });
  if (target) { const y = H - p.b - target / max * ph; g += `<line x1="${p.l}" x2="${W - p.r}" y1="${y}" y2="${y}" stroke="#d1344b" stroke-width="2" stroke-dasharray="6 4"/><text x="${W - p.r}" y="${y - 4}" text-anchor="end" style="fill:#d1344b">Seasonal recharge target ${target} kL/day</text>`; }
  return {
    svg: `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Water consumption chart">${g}</svg>`,
    legend: names.map((nm, i) => `<span><i style="background:${cols[i]}"></i>${esc(nm)}</span>`).join('')
  };
}

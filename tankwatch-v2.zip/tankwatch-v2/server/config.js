'use strict';
const path = require('path');
const crypto = require('crypto');

function loadConfig(env = process.env) {
  const prod = env.NODE_ENV === 'production';
  if (prod && (!env.ADMIN_PASSWORD || !env.TOKEN_SECRET)) {
    throw new Error('ADMIN_PASSWORD and TOKEN_SECRET must be set in production');
  }
  return {
    port: Number(env.PORT) || 3000,
    prod,
    adminUser: env.ADMIN_USER || 'operator',
    adminPassword: env.ADMIN_PASSWORD || 'tankwatch-demo',   // demo default, never used in production
    tokenSecret: env.TOKEN_SECRET || crypto.randomBytes(32).toString('hex'),
    tokenTtlSec: 8 * 3600,
    tickMs: 1500,
    dataFile: path.join(__dirname, '..', 'data', 'state.json'),
    eventLog: path.join(__dirname, '..', 'data', 'events.log')
  };
}
module.exports = { loadConfig };

'use strict';
const path = require('path');
const express = require('express');
const { apiRouter } = require('./routes/api');
const { securityHeaders } = require('./middleware/security');
const { notFound, errorHandler } = require('./middleware/errors');

/** Builds the Express app. Dependencies are injected so tests can run it without a network port or timers. */
function createApp({ sim, logger, config }) {
  const app = express();
  app.disable('x-powered-by');
  app.use(securityHeaders);
  app.use(express.json({ limit: '10kb' }));
  app.use('/api', apiRouter({ sim, logger, config }));
  app.use('/api', notFound);
  app.use(express.static(path.join(__dirname, '..', 'public')));
  app.use(errorHandler);
  return app;
}
module.exports = { createApp };

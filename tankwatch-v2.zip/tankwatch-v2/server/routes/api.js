'use strict';
const express = require('express');
const V = require('../services/validation');
const A = require('../services/auth');
const { requireAuth } = require('../middleware/auth');
const { WARDS } = require('../services/simulation');

/** Unwraps a validation result: sends 400 and returns null on failure. */
const check = (res, r) => r.ok ? r.value : (res.status(400).json({ error: r.error }), null);

function apiRouter({ sim, logger, config }) {
  const r = express.Router();
  const auth = requireAuth(config.tokenSecret);
  const adminHash = A.hashPassword(config.adminPassword);
  const allowLogin = A.createLimiter(5, 15 * 60 * 1000);
  const count = () => sim.S.tanks.length;

  /* ---- public, read-only ---- */
  r.get('/health', (req, res) => res.json({ ok: true }));
  r.get('/state', (req, res) => res.json(sim.snapshot()));

  r.post('/auth/login', (req, res) => {
    if (!allowLogin(req.ip)) { logger.log('login_throttled', { ip: req.ip }); return res.status(429).json({ error: 'too many attempts, try later' }); }
    const c = check(res, V.credentials(req.body)); if (!c) return;
    const userOk = c.username === config.adminUser, passOk = A.verifyPassword(c.password, adminHash);
    if (!(userOk && passOk)) { logger.log('login_failed', { ip: req.ip }); return res.status(401).json({ error: 'invalid credentials' }); }
    logger.log('login', { user: c.username });
    res.json({ token: A.createToken(c.username, config.tokenSecret, config.tokenTtlSec), user: c.username });
  });

  /* ---- operator-only commands ---- */
  r.use(auth);
  r.get('/events', (req, res) => res.json({ events: logger.recent(100), pumpFailures: logger.pumpFailures() }));

  r.post('/tanks/:id/mode', (req, res) => {
    const id = check(res, V.tankId(req.params.id, count())); if (id === null) return;
    const m = check(res, V.mode(req.body && req.body.mode)); if (!m) return;
    sim.setMode(id, m, req.user); res.json(sim.snapshot());
  });
  r.post('/tanks/:id/trip', (req, res) => {
    const id = check(res, V.tankId(req.params.id, count())); if (id === null) return;
    if (typeof (req.body && req.body.trip) !== 'boolean') return res.status(400).json({ error: 'trip must be true or false' });
    sim.setTrip(id, req.body.trip, req.user); res.json(sim.snapshot());
  });
  r.put('/tanks/:id/schedule', (req, res) => {
    const id = check(res, V.tankId(req.params.id, count())); if (id === null) return;
    const s = check(res, V.schedule(req.body)); if (!s) return;
    sim.setSchedule(id, s, req.user); res.json(sim.snapshot());
  });
  r.post('/tanks/:id/burst', (req, res) => {
    const id = check(res, V.tankId(req.params.id, count())); if (id === null) return;
    sim.toggleBurst(id, req.user); res.json(sim.snapshot());
  });
  r.post('/slots', (req, res) => {
    const s = check(res, V.slot(req.body, WARDS.length, sim.S.slots.length)); if (!s) return;
    sim.addSlot(s, req.user); res.json(sim.snapshot());
  });
  r.delete('/slots/:i', (req, res) => {
    if (!/^\d+$/.test(req.params.i) || !sim.removeSlot(Number(req.params.i), req.user)) return res.status(404).json({ error: 'unknown slot' });
    res.json(sim.snapshot());
  });
  r.post('/recharge', (req, res) => {
    const v = check(res, V.recharge(req.body)); if (!v) return;
    sim.recharge(v.mm, v.ha, req.user); res.json(sim.snapshot());
  });
  r.post('/sim/skip', (req, res) => { sim.tick(36); res.json(sim.snapshot()); });
  r.post('/sim/speed', (req, res) => {
    const s = check(res, V.speed(req.body && req.body.speed)); if (!s) return;
    sim.setSpeed(s); res.json(sim.snapshot());
  });
  r.post('/sim/reset', (req, res) => { sim.reset(req.user); res.json(sim.snapshot()); });
  return r;
}
module.exports = { apiRouter };

'use strict';
const { loadConfig } = require('./config');
const { createApp } = require('./app');
const { Simulation } = require('./services/simulation');
const { createLogger } = require('./services/logger');
const { loadState, saveState } = require('./services/store');

const config = loadConfig();
const logger = createLogger({ file: config.eventLog });
const sim = new Simulation({ state: loadState(config.dataFile), logger });
if (!sim.S.upd) sim.S.upd = Date.now();

setInterval(() => { sim.tick(sim.S.speed); }, config.tickMs);
setInterval(() => saveState(config.dataFile, sim.S), 10000).unref();

const server = createApp({ sim, logger, config }).listen(config.port, () => {
  console.log(`TankWatch running on http://localhost:${config.port}`);
  if (!process.env.ADMIN_PASSWORD) console.log('Using demo operator login (operator / tankwatch-demo). Set ADMIN_PASSWORD in .env to change.');
});
const shutdown = () => { saveState(config.dataFile, sim.S); server.close(() => process.exit(0)); };
process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);

'use strict';
/** Audit/event log: bounded in-memory ring buffer, optionally mirrored to a JSON-lines file. */
const fs = require('fs');

function createLogger({ file = null, max = 500, clock = Date.now } = {}) {
  const events = [];
  return {
    log(type, data = {}) {
      const e = { t: new Date(clock()).toISOString(), type, ...data };
      events.push(e);
      if (events.length > max) events.shift();
      if (file) { try { fs.appendFileSync(file, JSON.stringify(e) + '\n'); } catch { /* logging must never crash the server */ } }
      return e;
    },
    recent(limit = 100, type) {
      const list = type ? events.filter(e => e.type === type) : events;
      return list.slice(-limit).reverse();
    },
    /** Trip counts per pump – feeds failure auditing. */
    pumpFailures() {
      return events.filter(e => e.type === 'pump_trip').reduce((m, e) => { m[e.pump] = (m[e.pump] || 0) + 1; return m; }, {});
    }
  };
}
module.exports = { createLogger };

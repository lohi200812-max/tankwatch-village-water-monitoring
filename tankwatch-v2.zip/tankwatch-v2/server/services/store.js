'use strict';
/** Tiny JSON persistence with atomic writes (write temp file, then rename). */
const fs = require('fs');

function loadState(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
}
function saveState(file, state) {
  try {
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(state));
    fs.renameSync(tmp, file);
    return true;
  } catch { return false; }
}
module.exports = { loadState, saveState };

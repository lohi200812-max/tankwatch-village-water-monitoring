'use strict';
/** Server-side validation. Every function returns { ok:true, value } or { ok:false, error }. */
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
const MODES = ['on', 'off', 'auto'];
const SPEEDS = [1, 4, 12];
const MAX_SLOTS = 20;
const ok = value => ({ ok: true, value });
const bad = error => ({ ok: false, error });
const mins = s => Number(s.slice(0, 2)) * 60 + Number(s.slice(3));
const isInt = v => typeof v === 'number' && Number.isInteger(v);

function time(v, label = 'time') {
  return typeof v === 'string' && TIME_RE.test(v) ? ok(v) : bad(`${label} must be HH:MM (24h)`);
}
function tankId(v, count) {
  const n = typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : v;
  return isInt(n) && n >= 0 && n < count ? ok(n) : bad('unknown tank');
}
function mode(v) { return MODES.includes(v) ? ok(v) : bad(`mode must be one of ${MODES.join(', ')}`); }
function speed(v) { return SPEEDS.includes(v) ? ok(v) : bad(`speed must be one of ${SPEEDS.join(', ')}`); }

/** Pump window pair [start, end]; end must be after start. */
function window(pair, label) {
  if (!Array.isArray(pair) || pair.length !== 2) return bad(`${label} must be [start, end]`);
  const a = time(pair[0], `${label} start`), b = time(pair[1], `${label} end`);
  if (!a.ok) return a;
  if (!b.ok) return b;
  if (mins(b.value) <= mins(a.value)) return bad(`${label} end must be after start`);
  if (mins(b.value) - mins(a.value) > 12 * 60) return bad(`${label} cannot exceed 12 hours`);
  return ok([a.value, b.value]);
}
/** Morning and evening windows must not overlap. */
function schedule(body) {
  if (!body || typeof body !== 'object') return bad('body required');
  const am = window(body.am, 'morning'), pm = window(body.pm, 'evening');
  if (!am.ok) return am;
  if (!pm.ok) return pm;
  if (mins(pm.value[0]) < mins(am.value[1])) return bad('evening window overlaps morning window');
  return ok({ am: am.value, pm: pm.value });
}
/** Distribution slot: ward index, start time, duration 10–180 min, must finish before midnight. */
function slot(body, wardCount, existing = 0) {
  if (!body || typeof body !== 'object') return bad('body required');
  if (existing >= MAX_SLOTS) return bad(`at most ${MAX_SLOTS} slots allowed`);
  if (!isInt(body.w) || body.w < 0 || body.w >= wardCount) return bad('unknown hamlet');
  const s = time(body.s, 'start');
  if (!s.ok) return s;
  if (!isInt(body.d) || body.d < 10 || body.d > 180) return bad('duration must be a whole number of minutes, 10–180');
  if (mins(s.value) + body.d > 1440) return bad('slot must finish before midnight');
  return ok({ w: body.w, s: s.value, d: body.d });
}
function recharge(body) {
  if (!body || typeof body !== 'object') return bad('body required');
  const { mm, ha } = body;
  if (typeof mm !== 'number' || !Number.isFinite(mm) || mm < 0 || mm > 300) return bad('rainfall must be 0–300 mm');
  if (typeof ha !== 'number' || !Number.isFinite(ha) || ha < 1 || ha > 50) return bad('catchment must be 1–50 ha');
  return ok({ mm, ha });
}
function credentials(body) {
  if (!body || typeof body.username !== 'string' || typeof body.password !== 'string') return bad('username and password required');
  if (body.username.length > 64 || body.password.length > 128) return bad('credentials too long');
  return ok({ username: body.username, password: body.password });
}
module.exports = { time, tankId, mode, speed, schedule, slot, recharge, credentials, MAX_SLOTS };

'use strict';
/** Simulation engine (data layer). All randomness comes from an injectable rng so tests are deterministic. */
const { REF_CAP, prof, isOffPeak, toHours } = require('./profile');
const F = require('./forecast');

const WARDS = ['East Hamlet', 'Colony', 'School', 'Main Bazaar'];
const SHARE = [.3, .25, .2, .25];
const DT = 5;                       // minutes per tick
const STATE_VERSION = 2;
const GW_MAX = 3000;

function freshState(rng = Math.random) {
  const rnd = (a, b) => a + rng() * (b - a);
  const mk = (id, name, cap, pump, p) => ({
    id, name, cap, pump, vol: cap * p, mode: 'auto', trip: false, run: false, volt: 415, leak: 0, flag: false, inn: 0, out: 0,
    net: Array(12).fill(-prof(17.5) * cap / REF_CAP), outs: Array(6).fill(prof(17.5) * cap / REF_CAP),
    sched: { am: ['05:00', '07:00'], pm: ['20:30', '23:00'] }
  });
  const hourly = Array.from({ length: 24 }, (_, i) => i < 17 ? prof(i) * 2.3 * 60 / 1000 : 0);
  const today = F.avg(hourly) * 24 * 0.7;
  return {
    v: STATE_VERSION, m: 17.5 * 60, day: 0, pumped: 0, gw: 900, speed: 1, upd: 0, hourly,
    tanks: [mk(0, 'Main Panchayat Tank', 50000, 2, .35), mk(1, 'North Hamlet Sump', 20000, 1, .62),
            mk(2, 'School Overhead Tank', 15000, 3, .8), mk(3, 'Farm Borewell', 30000, 4, .5)],
    slots: [{ w: 0, s: '06:00', d: 45 }, { w: 1, s: '18:00', d: 45 }, { w: 2, s: '08:00', d: 30 }, { w: 3, s: '19:00', d: 45 }],
    log: [],
    week: Array.from({ length: 7 }, (_, i) => SHARE.map(s => (i < 6 ? rnd(100, 130) : today) * s))
  };
}

class Simulation {
  constructor({ state, rng = Math.random, logger = null, clock = Date.now } = {}) {
    this.rng = rng; this.logger = logger; this.clock = clock;
    this.S = state && state.v === STATE_VERSION ? state : freshState(rng);
    this.tiers = this.S.tanks.map(F.tier);
  }
  _log(type, data) { if (this.logger) this.logger.log(type, data); }

  /** Advance one 5-minute tick. */
  step() {
    const S = this.S; S.m += DT;
    const day = Math.floor(S.m / 1440), dm = S.m % 1440, h = dm / 60;
    if (day !== S.day) {
      S.week.shift(); S.week.push([0, 0, 0, 0]); S.hourly = Array(24).fill(0);
      S.gw = Math.max(0, S.gw - S.pumped); S.pumped = 0; S.day = day;
    }
    let tot = 0;
    S.tanks.forEach((k, i) => {
      const base = prof(h) * k.cap / REF_CAP;
      let out = base * (.9 + this.rng() * .2) + k.leak;
      if (k.id === 0) S.slots.forEach(sl => { const a = toHours(sl.s) * 60; if (dm >= a && dm < a + sl.d) { out += 45; this._logMinutes(sl, day); } });
      const inWindow = [k.sched.am, k.sched.pm].some(([a, z]) => h >= toHours(a) && h < toHours(z));
      let on = !k.trip && (k.mode === 'on' || (k.mode === 'auto' && inWindow));
      if (on && this.rng() < .0015) {                                  // rare random pump trip
        k.trip = true; on = false;
        this._log('pump_trip', { pump: k.pump, tank: k.name, day: S.day + 1, at: this.clockStr() });
      }
      k.run = on;
      k.volt = k.trip ? 0 : on ? Math.round(405 + this.rng() * 20) : Math.round(412 + this.rng() * 6);
      k.inn = on ? 150 * k.cap / REF_CAP : 0; k.out = out;
      k.vol = F.clamp(k.vol + (k.inn - out) * DT, 0, k.cap);
      k.net.push(k.inn - out); k.net.shift();
      k.outs.push(out); k.outs.shift();
      const wasFlag = k.flag;
      k.flag = F.isLeaking(k.outs, base, isOffPeak(h));
      if (k.flag && !wasFlag) this._log('leak_flagged', { tank: k.name });
      const t = F.tier(k);
      if (t !== this.tiers[i]) { this._log('tier_change', { tank: k.name, from: this.tiers[i], to: t }); this.tiers[i] = t; }
      tot += out * DT / 1000; S.pumped += k.inn * DT / 1000;
    });
    S.hourly[Math.floor(h)] += tot; SHARE.forEach((s, i) => S.week[6][i] += tot * s);
    S.upd = this.clock();
  }
  tick(n = 1) { for (let i = 0; i < n; i++) this.step(); }
  clockStr() { const m = Math.floor(this.S.m % 1440); return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); }

  _logMinutes(sl, day) {
    const S = this.S;
    let e = S.log.find(x => x.day === day && x.w === sl.w && x.s === sl.s);
    if (!e) { e = { day, w: sl.w, s: sl.s, min: 0 }; S.log.push(e); if (S.log.length > 40) S.log.shift(); }
    e.min += DT;
  }

  /* ---- commands (inputs are validated by the caller) ---- */
  setMode(id, mode, by = 'system') {
    const k = this.S.tanks[id]; k.mode = mode;
    if (k.trip && mode !== 'off') k.trip = false;
    k.run = !k.trip && mode === 'on';
    this._log('pump_mode', { pump: k.pump, tank: k.name, mode, by });
  }
  setTrip(id, trip, by = 'system') {
    const k = this.S.tanks[id]; k.trip = trip; if (trip) k.run = false;
    this._log(trip ? 'pump_trip_manual' : 'pump_reset', { pump: k.pump, tank: k.name, by });
  }
  setSchedule(id, sched, by = 'system') {
    const k = this.S.tanks[id]; k.sched = { am: [...sched.am], pm: [...sched.pm] };
    this._log('schedule_changed', { tank: k.name, ...k.sched, by });
  }
  addSlot(slot, by = 'system') { this.S.slots.push(slot); this._log('slot_added', { ...slot, by }); }
  removeSlot(i, by = 'system') {
    if (!Number.isInteger(i) || i < 0 || i >= this.S.slots.length) return false;
    const [s] = this.S.slots.splice(i, 1); this._log('slot_removed', { ...s, by }); return true;
  }
  toggleBurst(id, by = 'system') {
    const k = this.S.tanks[id]; k.leak = k.leak ? 0 : 120 * k.cap / REF_CAP;
    this._log(k.leak ? 'burst_simulated' : 'burst_repaired', { tank: k.name, by });
  }
  recharge(mm, ha, by = 'system') {
    this.S.gw = Math.min(GW_MAX, this.S.gw + mm * ha * 1.5);
    this._log('recharge_applied', { mm, ha, by });
  }
  setSpeed(speed) { this.S.speed = speed; }
  reset(by = 'system') { this.S = freshState(this.rng); this.tiers = this.S.tanks.map(F.tier); this._log('reset', { by }); }

  /** JSON-safe view for clients, with forecasts computed server-side. */
  snapshot() {
    const S = this.S;
    return {
      m: S.m, day: S.day, clock: this.clockStr(), upd: S.upd, speed: S.speed, gw: S.gw,
      dailyUse: Math.max(60, S.week[5].reduce((a, b) => a + b, 0)),
      wards: WARDS, shares: SHARE, hourly: S.hourly, week: S.week, slots: S.slots, log: S.log.slice(-40),
      tanks: S.tanks.map(k => {
        const h = (S.m % 1440) / 60;
        return {
          id: k.id, name: k.name, cap: k.cap, vol: k.vol, pump: k.pump, mode: k.mode, trip: k.trip, run: k.run, volt: k.volt,
          inn: k.inn, out: k.out, leak: k.leak, flag: k.flag, sched: k.sched, tier: F.tier(k),
          hoursLeft: F.hoursLeft(k), fillHours: F.fillHours(k),
          avgOut: F.avg(k.outs), benchmark: prof(h) * k.cap / REF_CAP
        };
      })
    };
  }
}
module.exports = { Simulation, freshState, WARDS, SHARE, STATE_VERSION };

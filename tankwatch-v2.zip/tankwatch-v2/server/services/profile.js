'use strict';
/** Typical village demand (L/min for a 50,000 L tank) by hour of day. */
const REF_CAP = 50000;
const prof = h => h < 5 ? 8 : h < 6 ? 25 : h < 9 ? 70 : h < 17 ? 30 : h < 20 ? 80 : h < 22 ? 35 : 15;
const isOffPeak = h => h < 5 || (h >= 11 && h < 15);
/** "HH:MM" -> fractional hours. */
const toHours = s => { const [a, b] = s.split(':'); return Number(a) + Number(b) / 60; };
module.exports = { REF_CAP, prof, isOffPeak, toHours };

'use strict';
/** Dependency-free auth: scrypt password hashing + HMAC-signed expiring tokens. */
const crypto = require('crypto');
const b64 = b => Buffer.from(b).toString('base64url');

function hashPassword(password, salt = crypto.randomBytes(16)) {
  const key = crypto.scryptSync(password, salt, 32);
  return `${salt.toString('hex')}:${key.toString('hex')}`;
}
function verifyPassword(password, stored) {
  const [saltHex, keyHex] = String(stored).split(':');
  if (!saltHex || !keyHex) return false;
  const key = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), 32);
  const want = Buffer.from(keyHex, 'hex');
  return want.length === key.length && crypto.timingSafeEqual(key, want);
}
function sign(payload, secret) { return crypto.createHmac('sha256', secret).update(payload).digest('base64url'); }

function createToken(sub, secret, ttlSec, now = Date.now()) {
  const body = b64(JSON.stringify({ sub, exp: Math.floor(now / 1000) + ttlSec }));
  return `${body}.${sign(body, secret)}`;
}
/** Returns the payload, or null if malformed, tampered with or expired. */
function verifyToken(token, secret, now = Date.now()) {
  if (typeof token !== 'string') return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const want = Buffer.from(sign(body, secret)), got = Buffer.from(sig);
  if (want.length !== got.length || !crypto.timingSafeEqual(want, got)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString());
    return p && p.exp > Math.floor(now / 1000) ? p : null;
  } catch { return null; }
}

/** Fixed-window limiter for login attempts, keyed by caller (e.g. IP). */
function createLimiter(max, windowMs, clock = Date.now) {
  const hits = new Map();
  return key => {
    const now = clock(), h = hits.get(key);
    if (!h || now - h.start > windowMs) { hits.set(key, { start: now, n: 1 }); return true; }
    h.n += 1;
    return h.n <= max;
  };
}
module.exports = { hashPassword, verifyPassword, createToken, verifyToken, createLimiter };

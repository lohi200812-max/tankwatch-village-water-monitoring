'use strict';
/** Pure forecasting helpers – no I/O, fully unit-tested. Flows are L/min, volumes litres. */
const avg = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const DRAIN_EPS = 0.5;   // L/min below which a tank is considered steady

/** Hours until empty at the current average net outflow, or null if not draining. */
function hoursLeft(tank) {
  const a = avg(tank.net);
  return a < -DRAIN_EPS ? tank.vol / -a / 60 : null;
}
/** Hours until full at the current average net inflow, or null if not filling / already full. */
function fillHours(tank) {
  const a = avg(tank.net);
  return a > DRAIN_EPS && tank.vol < tank.cap ? (tank.cap - tank.vol) / a / 60 : null;
}
/** Alert tier from fill percentage. */
function tier(tank) {
  const p = tank.vol / tank.cap * 100;
  return p < 20 ? 'crit' : p < 40 ? 'warn' : p >= 95 ? 'over' : 'ok';
}
/** Leak heuristic: sustained off-peak outflow far above the benchmark. */
function isLeaking(recentOuts, benchmark, offPeak) {
  return offPeak && avg(recentOuts) > 2.2 * benchmark + 10;
}
/** Recharge volume (m³) from rainfall (mm) over a catchment (ha), 15% runoff coefficient. */
const rechargeM3 = (mm, ha) => mm * ha * 10 * 0.15;

module.exports = { avg, clamp, hoursLeft, fillHours, tier, isLeaking, rechargeM3 };

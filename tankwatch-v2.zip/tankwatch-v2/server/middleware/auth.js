'use strict';
const { verifyToken } = require('../services/auth');

/** Requires `Authorization: Bearer <token>`; sets req.user on success. */
function requireAuth(secret) {
  return (req, res, next) => {
    const m = /^Bearer (.+)$/.exec(req.get('authorization') || '');
    const p = m && verifyToken(m[1], secret);
    if (!p) return res.status(401).json({ error: 'authentication required' });
    req.user = p.sub;
    next();
  };
}
module.exports = { requireAuth };

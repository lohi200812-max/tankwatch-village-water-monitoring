'use strict';
function notFound(req, res) { res.status(404).json({ error: 'not found' }); }
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'invalid JSON' });
  if (err && err.type === 'entity.too.large') return res.status(413).json({ error: 'payload too large' });
  console.error(err);
  res.status(500).json({ error: 'internal error' });
}
module.exports = { notFound, errorHandler };
